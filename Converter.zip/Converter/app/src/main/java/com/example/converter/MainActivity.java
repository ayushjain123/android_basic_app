package com.example.converter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buttonconvtokm= (Button) findViewById(R.id.buttonconvtokm);
        buttonconvtokm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText textBoxMiles =(EditText) findViewById(R.id.editTextmiles);
                EditText textBoxkm= (EditText) findViewById(R.id.editTextkm);
                Double vmiles= Double.valueOf(textBoxMiles.getText().toString());
                Double vkm= vmiles/.6213;
                DecimalFormat formatVal= new DecimalFormat("##.##");
                textBoxkm.setText(formatVal.format(vkm));

            }
        });

        Button buttonconvtomiles= (Button) findViewById(R.id.buttonconvtomiles);
        buttonconvtomiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText textBoxMiles= (EditText) findViewById(R.id.editTextmiles);
                EditText textBoxkm = (EditText) findViewById(R.id.editTextkm);
                Double vkm= Double.valueOf(textBoxMiles.getText().toString());
                Double vmiles= vkm*.6213;
                DecimalFormat formatVal= new DecimalFormat("##.##");
                textBoxMiles.setText(formatVal.format(vmiles));


            }
        });

    }
}
